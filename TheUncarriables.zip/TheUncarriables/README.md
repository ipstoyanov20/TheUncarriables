<img src = "https://cdn.discordapp.com/attachments/908296425492856833/917488567415107624/unknown.png">

<p><b>Team</b><br>Ivaylo Stoqnov - Scrum Trainer<br>Denislav Bratoevski - QA<br>Ivan Tsrangalov - Back-end developer<br>Hakan Chandar - Back-end developer</p>

<p><b>IMPORTANT!</b></p>
<p><b>In order to run the game properly, you must extract the .zip file.</b></p>
